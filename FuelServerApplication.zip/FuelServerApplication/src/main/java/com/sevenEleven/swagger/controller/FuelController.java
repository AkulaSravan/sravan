package com.sevenEleven.swagger.controller;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sevenEleven.swagger.beans.Product;

import io.swagger.annotations.Api;



@RestController
@Configuration
@EnableAutoConfiguration
@ControllerAdvice
@Api(value="Fuel Server API", description="Information Of Servicess in Fuel Server")
public class FuelController {

	@RequestMapping(value = "/fcserver/getProduct/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Product getProduct(@PathVariable Integer id,Model model)
			throws Exception {
		System.out.println("In FuelController getProduct :: id :: "+id.toString());
		Product response = new Product();
		response.setProductId(101);
		response.setProductName("Book");
		response.setProductDescription("A Journey Of 100 Centuries");
		return response;
	}
}
